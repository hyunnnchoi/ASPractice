﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public enum ComboBoxParseCase
    {
        None, Year, Month, Day, Combine
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmb_ItemOrTextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime localDate = DateTime.Now;
            for (int i = localDate.Year - 1000; i <= localDate.Year + 1000; i++) cmbYear.Items.Add(i);
            cmbYear.SelectedIndex = cmbYear.Items.Count - 1;

            for (int i = 1; i <= 12; i++) cmbMonth.Items.Add(i);
            for (int i = 1; i <= 31; i++) cmbDay.Items.Add(i);

        }

        public bool IsDate(int year, int month, int day)
        {
            return year >= 0 && month > 0 && month < 13 && day > 0 && day <= DateTime.DaysInMonth(year, month);
        }

        private ComboBoxParseCase GetComboBoxParseCase()
        {
            if (cmbYear.SelectedItem == null) return ComboBoxParseCase.Year;
            else if (cmbMonth.SelectedItem == null) return ComboBoxParseCase.Month;
            else if (cmbDay.SelectedItem == null) return ComboBoxParseCase.Day;
            else if (cmbDay.SelectedItem == null) return ComboBoxParseCase.Day;
            else if (!IsDate((int)cmbYear.SelectedItem,
                (int)cmbMonth.SelectedItem,
                (int)cmbDay.SelectedItem)) return ComboBoxParseCase.Combine;

            return ComboBoxParseCase.None;
        }
    }
}
