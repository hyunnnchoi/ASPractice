﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.Win32;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
            InitializeFileDilaog();

        }
        private void SaveSetting()
        {
            try
            {
                RegistryKey rk = Registry.CurrentUser.CreateSubKey(@"C# Notepad\Notepad");

                var FontName = txtBox.Font.FontFamily.GetName(0);
                var FontSize = Convert.ToString(txtBox.Font.Size);
                var ForeColor = Convert.ToString(txtBox.ForeColor.ToArgb());
                var BackColor = Convert.ToString(txtBox.BackColor.ToArgb());

                rk.SetValue("FontName", FontName);
                rk.SetValue("FontSize", FontSize);
                rk.SetValue("ForeColor", ForeColor);
                rk.SetValue("BackColor", BackColor);

            }
            catch (Exception) { }
        }
        private void LoadSetting()
        {
            try
            {
                RegistryKey rk = Registry.CurrentUser.OpenSubKey(@"C# Notepad\Notepad");

                var FontName = Convert.ToString(rk.GetValue("FontName"));
                var FontSize = Convert.ToSingle(rk.GetValue("FontSize"));

                var ForeColor = Convert.ToInt32(rk.GetValue("ForeColor"));
                var BackColor = Convert.ToInt32(rk.GetValue("BackColor"));

                txtBox.Font = new System.Drawing.Font(FontName, FontSize);
                txtBox.ForeColor = System.Drawing.Color.FromArgb(ForeColor);
                txtBox.BackColor = System.Drawing.Color.FromArgb(BackColor);

                fnd.Font = txtBox.Font;
            }
            catch (Exception) { }
        }
        private void InitializeFileDilaog()
        {
            this.ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            ofd.Filter = "Text (*.txt)|*.txt|" + "All files (*.*)|*.*";
            ofd.FileName = "";

            sfd.InitialDirectory = ofd.InitialDirectory;
            sfd.Filter = ofd.Filter;
            sfd.FileName = "*.txt";
        }

        private void 열기OToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                //stream Open
                Stream stream = ofd.OpenFile();
                StreamReader sr = new StreamReader(stream);

                //read file
                txtBox.Text = sr.ReadToEnd();

                //stream close
                sr.Close();
                stream.Close();

                Text = Path.GetFileName(ofd.FileName);
            }
        }

        private void tsmiBackColor_Click(object sender, EventArgs e)
        {
            if (cld.ShowDialog() == DialogResult.OK)
                txtBox.BackColor = cld.Color;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             //LoadSetting();
        }

        private void tsmiNew_Click(object sender, EventArgs e)
        {
            Text = "Notepad";
            txtBox.Text = string.Empty;
        }

        private void tsmiSave_Click(object sender, EventArgs e)
        {
            if(ofd.FileName == "")
            {
                tsmiSaveAs_Click(tsmiSaveAs, EventArgs.Empty);
                return;
            }
            sfd.FileName = ofd.FileName;
            Stream stream = sfd.OpenFile();
            StreamWriter sw = new StreamWriter(stream);

            sw.Write(txtBox.Text);

            sw.Close();
            stream.Close();

            Text = Path.GetFileName(sfd.FileName);
        }

        private void tsmiSaveAs_Click(object sender, EventArgs e)
        {
            if(sfd.ShowDialog() == DialogResult.OK)
            {
                ofd.FileName = sfd.FileName;
                tsmiSave_Click(tsmiSave, EventArgs.Empty);
            }
        }

        private void tsmiExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tsmiUndo_Click(object sender, EventArgs e)
        {
            txtBox.Undo();
        }

        private void tsmiCut_Click(object sender, EventArgs e)
        {
            txtBox.Cut();
        }

        private void tsmiCopy_Click(object sender, EventArgs e)
        {
            txtBox.Copy();
        }

        private void tsmiPaste_Click(object sender, EventArgs e)
        {
            txtBox.Paste();
        }

        private void tsmiSelectAll_Click(object sender, EventArgs e)
        {
            txtBox.SelectAll();
        }

        private void tsmiDel_Click(object sender, EventArgs e)
        {
            txtBox.SelectedText = string.Empty;

        }

        private void tsmiWordWrap_Click(object sender, EventArgs e)
        {
            txtBox.WordWrap = !txtBox.WordWrap;
            tsmiWordWrap.Checked = txtBox.WordWrap;
        }

        private void tsmiFont_Click(object sender, EventArgs e)
        {
            if (fnd.ShowDialog() == DialogResult.OK)
                txtBox.Font = fnd.Font;
        }

        private void tsmiFontColor_Click(object sender, EventArgs e)
        {
            if (cld.ShowDialog() == DialogResult.OK)
                txtBox.ForeColor = cld.Color;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSetting();
        }
    }
}
