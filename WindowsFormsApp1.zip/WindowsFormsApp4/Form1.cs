﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lvwPeopleInfo.View = View.Details;

            lvwPeopleInfo.Columns.Add("Name", "Name");
            lvwPeopleInfo.Columns.Add("Age", "Age");
            lvwPeopleInfo.Columns.Add("Gender", "Gender");
            lvwPeopleInfo.Columns.Add("last", "last");

            lvwPeopleInfo.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            lvwPeopleInfo.Columns.RemoveByKey("last");

            lvwPeopleInfo.Columns[0].TextAlign = HorizontalAlignment.Left;
            lvwPeopleInfo.Columns["Age"].TextAlign = HorizontalAlignment.Center;
            lvwPeopleInfo.Columns[2].TextAlign = HorizontalAlignment.Right;
        }
    }
}
